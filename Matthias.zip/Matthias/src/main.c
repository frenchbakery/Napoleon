#include <kipr/wombat.h>

int main()
{
    int LIGHT = 0;
    int DIST = 1;
    int BUTTON_1 = 0;
    int BUTTON_2 = 1;
    int BOOL = 1;
    int GRAP_DIST = 1500;
    int GRAP_OPEN = 400;
    
    enable_servo(0);
    set_servo_position(0,GRAP_OPEN);
    printf("Auf Licht warten\n");
    while(1){
    msleep(200);
    if (analog(LIGHT) < 500){
    	break;
    	}
    }
    shut_down_in(119);
    
    printf("Start\n");
    while(BOOL == 1){
    	motor(0,50);
   		motor(1,50);
    	if(analog(DIST) > 2900){
            printf("Objekt erkannt!\n");
            while(1){
    			motor(0,20);
                motor(1,20);
                if (analog(DIST) == GRAP_DIST){
                set_servo_position(0,0);
                }
                motor(0,-50);
                motor(1,-50);
                if (digital(BUTTON_1)==1 && digital(BUTTON_2)==1){
                	printf("Ausgerichtet\n\n");
                    motor(0,0);
                    motor(1,0);
                    BOOL = 0;
                   	break;
                }  
    		}
   		}
    }
    return 0;
}